from django.apps import AppConfig


class PlacementConfig(AppConfig):
    name = 'placement'
